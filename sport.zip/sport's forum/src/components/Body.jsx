export default function Body () {

  const forumData = [
    {
      id: 1,
      title: 'Introduction to Fitness',
      content: 'Discuss different fitness routines, exercises, and tips for staying healthy and active.',
    },
    {
      id: 2,
      title: 'Nutrition and Diet',
      content: 'Share your favorite healthy recipes, dietary advice, and nutritional tips.',
    },
    {
      id: 3,
      title: 'Mindfulness and Mental Health',
      content: 'Explore strategies for managing stress, improving mental health, and practicing mindfulness.',
    },
    // Add more forum posts here
  ];



    return (
      <>
        <div className="flex flex-col min-h-screen">
          <div className="grid h-20 card bg-base-300 rounded-box place-items-center">This forum is about physical health and people who would like to be healthy, to have a proper movement culture in their lives
          </div>
          <div className="flex flex-col w-full lg:flex-row">
            <div className="grid flex-grow h-32 card bg-blue-300 rounded-box place-items-center">User base: {}</div> 
            <div className="divider divider-horizontal" />  
            <div className="grid flex-grow h-32 card bg-blue-300 rounded-box place-items-center">Post base: {}</div>
          </div>
          <span className="border p-4 border-style: solid;"/>
          <div className="flex flex-col w-full lg:flex-row">
            <div className="grid flex-grow h-32 card bg-blue-300 rounded-box place-items-left">
              <h2>This is our lates post about.....</h2>
              <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Ab voluptate explicabo iure temporibus, aut perferendis laboriosam autem neque quo eligendi, deleniti laudantium sed consequatur aspernatur soluta debitis et dolorem unde.
              </p>
              {forumData.map((post) => (
              <div className="grid flex-grow h-32 card bg-base-300 rounded-box place-items-left" key={post.id}>
                <h2>{post.title}</h2>
                <p>{post.content}</p>
              </div>
            ))}  
            </div>
            <div className="divider divider-horizontal" />  
            <div className="grid flex-grow h-32 card bg-blue-300 rounded-box place-items-left">
              <h2>This is our most commented post....</h2>
              <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Porro, quis. Tempore nemo unde saepe accusamus dolorem nulla quam temporibus quod? Facere harum incidunt sed similique vero, nobis ad illo earum?
              </p>
              {forumData.map((post) => (
              <div className="grid flex-grow h-32 card bg-base-300 rounded-box place-items-left" key={post.id}>
                <h2>{post.title}</h2>
                <p>{post.content}</p>
              </div>
            ))}
            </div>
          </div>
        </div>
      </>
    );
  }
  