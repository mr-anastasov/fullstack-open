export default function Header() {

    return (
        <>
            <header className='header'>Welcome to the Forum App!</header>
        </>
    )
}

