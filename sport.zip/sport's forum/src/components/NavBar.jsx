import { NavLink } from 'react-router-dom'
import { useContext } from 'react'
import { AuthContext } from '../context/AuthContext';
import { logoutUser } from '../services/AuthService'

export default function Navbar() {
    const { user, setUser } = useContext(AuthContext);

    const onLogout = () => {
        logoutUser()
            .then(() => {
                setUser({
                    user: null
                });
            })
    }

    return (
        <nav className='navigation'>
            <div className='flex space-x-4'>
                <NavLink to="/" className="inline-block">
                    <img className='logo' src="" alt="Forum App Logo" />
                </NavLink>  
                <NavLink to="/home" className="inline-block">Home</NavLink>
                <NavLink to="/about" className="inline-block">About</NavLink>
                {user === null && <NavLink to="/log-in" className="inline-block">Log In</NavLink>}
                {user === null && <NavLink to="/sign-up" className="inline-block">Sign Up</NavLink>}
                {user !== null && <NavLink to="/log-out" className="inline-block" onClick={onLogout}>Log Out</NavLink>}
                {user !== null && <NavLink to="/create-post" className="inline-block">Create post</NavLink>}
            </div>
        </nav>
    )
}
