import { useState } from "react"

export default function SearchBar({onChange}) {

    const [searchTerm, setSearchTerm] = useState('');

    const handleSearchClick = () => {
        onChange(searchTerm);
    }


    return (
        <div className="search-bar">
            <label htmlFor="search">Search</label>
          <input
            type="text"
            placeholder="Search..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
          <button onClick={handleSearchClick}>Search</button>           
        </div>
    )    
}