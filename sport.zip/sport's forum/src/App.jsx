import Footer from "./components/Footer"
import Header from "./components/Header"

import NavBar from "./components/NavBar";
import { Routes, Route } from "react-router-dom";
import { useState, useEffect } from "react";
import Home from "./views/Home";
import LogIn from "./views/LogIn";
import CreatePost from "./views/CreatePost"
import { auth } from "./config/firebase-config";
import { useAuthState } from "react-firebase-hooks/auth"
import { getUserData } from "./services/UserService";
import AuthContext from "./context/AuthenticatedRoute";


function App() {

  const [user] = useAuthState(auth);
  const [appState, setAppState] = useState({
    user,
    userData: null,
  });

  if(appState.user !== user){
    setAppState({user});
  }

  useEffect(() => {

    if(user === null){
      return;
    }

    getUserData(user.uid)
      .then(snapshot => {
        if(!snapshot.exists()){
          throw new Error('User data not found');
        }

        setAppState({
          ...appState,
          userData: snapshot.val(Object.keys(snapshot.val())[0])
        });
      }, [user]);
  })


  return (
    <>
    <Header />
      <AuthContext.Provider value ={{ ...appState, setUser: setAppState}}>
        <NavBar />
        <Routes>
          <Route path="home" element={<Home />} />
          {user === null && <Route path="log-in" element={<LogIn />} />}
          {user === null && <Route path="log-in" element={<CreatePost />} />}
        </Routes>
      </AuthContext.Provider>
      <Footer />
    </>
  )
}

export default App
