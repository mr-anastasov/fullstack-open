import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getDatabase } from 'firebase/database';

export const firebaseConfig = {
    apiKey: "AIzaSyC_vjXBx5VdXhqUPs2-JZADfxQBo636338",
    authDomain: "forum-project-61a83.firebaseapp.com",
    databaseURL: "https://forum-project-61a83-default-rtdb.europe-west1.firebasedatabase.app",
    projectId: "forum-project-61a83",
    storageBucket: "forum-project-61a83.appspot.com",
    messagingSenderId: "195413779986",
    appId: "1:195413779986:web:fd7927c5d3ede3754d9acb",
  }

export const app = initializeApp(firebaseConfig);
// the Firebase authentication handler
export const auth = getAuth(app);
// the Realtime Database handler
export const db = getDatabase(app);