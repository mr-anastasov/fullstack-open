import { createUserWithEmailAndPassword, signInWithEmailAndPassword, signOut } from "firebase/auth";
import { auth } from "../config/firebase-config";

export const registerUser = (email, password, firstName, lastName) => {
    return createUserWithEmailAndPassword(auth, email, password, firstName, lastName);
}

export const loginUser = (email, password) => {
    return signInWithEmailAndPassword(auth, email, password);
}

export const logoutUser = () => {
    return signOut(auth);
}
