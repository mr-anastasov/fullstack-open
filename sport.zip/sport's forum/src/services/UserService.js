import { get, set, ref, query, orderByChild, equalTo } from "firebase/database";
import { db } from "../config/firebase-config";

export const getUserByHandle = (handle) => {
    return get(ref(db, `users/${handle}`));
}

export const createUserHandle = (handle, uid, email) => {
    return set(ref(db, `users/${handle}`), {
        uid,
        email,
        createdOn: Date.now(),
        likedPosts: {}
    });
}

export const getUserData = (uid) => {
    return get(ref(db, 'users'), orderByChild('uid'), equalTo(uid));
}
