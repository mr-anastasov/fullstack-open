import { useState } from "react"
// import { AuthContext } from "../../context/AuthContext";


export default function CreatePost() {

    
    // const { setUser } = useContext(AuthContext);


    const [post, createPost ] = useState({
        title: '',
        content: '',
        file: '',
    });

    const handleInputChange = (event) => {
        const {name, value } = event.target;
        createPost((prevData) => ({
            ...prevData,
            [name]: value,
        }));
    }

    

    const handleSubmit = (event) => {
        event.preventDefault();
        console.log('Form Data:', post)
    };

    return (
        <>
            <h1>Write your post here</h1>
            <form onSubmit={handleSubmit}>
                <label htmlFor="title">Title</label>
                <input type="text" id="title" name="title" value={post.title} onChange={handleInputChange} placeholder="Write some meaningful title here" className="w-64 h-16 p-2 rounded border border-gray-300 focus:ring focus:ring-blue-300"/>
                <label htmlFor="content">Content</label>
                <input type="text" id="content" name="content" value={post.content} onChange={handleInputChange} placeholder="Write your post in here, and make it as structured as possible, add pictures for a better understanding." />
                <label htmlFor="file">File upload</label>
                <input type="file" id="file" name="file" value={post.file} onChange={handleInputChange} placeholder="You can upload your picture here"/>
            </form>      
        </>
    )
}