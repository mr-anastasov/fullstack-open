
export default function About() {
    return (
        <div className="about">
            <div className="container">
                <h1>Health and Sport Forum</h1>

                <div className="forum-section">
                    <h2>Fitness: The Journey to a Stronger You</h2>
                    <p>Insert your fitness discussions, tips, and stories here.</p>
                </div>

                <div className="forum-section">
                    <h2>Nutrition: Fueling Your Body Wisely</h2>
                    <p>Insert your nutrition-related topics and recipes here.</p>
                </div>

                <div className="forum-section">
                    <h2>Mental Health: The Key to Resilience</h2>
                    <p>Share your stress management and mindfulness insights here.</p>
                </div>

                <div className="forum-section">
                    <h2>Injury Prevention and Recovery</h2>
                    <p>Discuss injury prevention strategies and recovery tips here.</p>
                </div>

                <div className="forum-section">
                    <h2>Inspiration and Motivation</h2>
                    <p>Share your inspirational stories and motivational experiences here.</p>
                </div>

                <div className="forum-section">
                    <h2>Ask the Experts</h2>
                    <p>Ask your health and fitness-related questions to our experts here.</p>
                </div>

                <p>
                    Remember, this forum is a place of mutual respect and support. Let's encourage one another in our health and sport
                    journeys and create a vibrant community together!
                </p>

                <p>Here is to a life of wellness and happiness!</p>

                <p>Best regards,<br />
                [VAM team]</p>
            </div>
        </div>
    );
}
