import Body from "../components/Body";
import Footer from "../components/Footer";
import SearchBar from "../components/Search";

export default function Home() {

    return (
        <>
            <SearchBar />
            <Body />
            <Footer />
        </>
    )
}