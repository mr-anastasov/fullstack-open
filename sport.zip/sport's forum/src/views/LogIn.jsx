import { AuthContext } from "../context/AuthContext";
import { useState, useContext } from "react";
import { loginUser } from "../services/AuthService";
import { useNavigate } from "react-router-dom";

export default function Signin() {

    const [form, setForm] = useState({
        email: '',
        password: '',
    });

    const [error, setError] = useState('');

    const { setUser } = useContext(AuthContext);
    const navigate = useNavigate();

    const updateForm = prop => e => {
        setForm({
            ...form,
            [prop]: e.target.value
        });
    }

    const onLogin = (e) => { 
        e.preventDefault();
        if (!form.email) {
            setError('Email is required');
            return;
        }

        if (!form.password || form.password.length < 6) {
            setError('Password is required and must be at least 6 characters');
            return;
        }

        loginUser(form.email, form.password)
            .then(credential => {
                setUser({
                    user: credential.user
                });
            })
            .then(() => {
                navigate('/');
            })
            .catch(error => {
                setError('Incorrect email or password'); // Set the error message for incorrect login
                console.error('Error during login:', error);
            });
    }

    return (
        <>
            <form onSubmit={(onLogin)}>
                <label htmlFor="email">Email</label>
                <input type="email" name="email" id="email" value={form.email} onChange={updateForm('email')} required={true} className="block max-w-sm rounded-lg bg-white p-6 shadow-[0_2px_15px_-3px_rgba(0,0,0,0.07),0_10px_20px_-2px_rgba(0,0,0,0.04)] dark:bg-neutral-700"/>
                <label htmlFor="password">Password</label>
                <input type="password" name="password" id="password" value={form.password} onChange={updateForm('password')} required={true}  className="block max-w-sm rounded-lg bg-white p-6 shadow-[0_2px_15px_-3px_rgba(0,0,0,0.07),0_10px_20px_-2px_rgba(0,0,0,0.04)] dark:bg-neutral-700"  />
                <button type="submit" className="block max-w-sm rounded-lg bg-white p-6 shadow-[0_2px_15px_-3px_rgba(0,0,0,0.07),0_10px_20px_-2px_rgba(0,0,0,0.04)] dark:bg-neutral-700">Log In</button>
            </form>
        </>
    )
}
