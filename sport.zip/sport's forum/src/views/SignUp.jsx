import { useState, useContext } from "react"
import { AuthContext } from "../context/AuthContext"
import { createUserHandle, getUserByHandle } from "../services/UserService"
import { registerUser } from "../services/AuthService"
import { useNavigate } from "react-router-dom"

export default function Signup() {
    const [form, setForm] = useState({
        email: '',
        firstName: '',
        lastName:'',
        password: '',
        handle: '',
    });

    const { setUser } = useContext(AuthContext);
    const navigate = useNavigate();


    const updateForm = prop => e => {
        setForm({
            ...form,
            [prop]: e.target.value
        });
    }

    const onRegister = () => {
        if(!form.email){
            return alert('Email is required');
        }

        if(!form.firstName || form.firstName.length < 4 || form.firstName.length > 32 ){
            return alert('First name is required and must be between 4 and 32 characters');
        }

        if(!form.lastName || form.lastName.length < 4 || form.lastName.length > 32 ){
            return alert('Last name is required and must be between 4 and 32 characters');
        }


        if(!form.password || form.password.length < 6){
            return alert('Password is required and must be at least 6 characters');
        }

        if(!form.handle){
            return alert('Handle is required');
        }

        getUserByHandle(form.handle)
            .then(snapshot => {
                if(snapshot.exists()){
                    return alert('Username already exists');
                }

                return registerUser(form.email, form.password);
            })
            .then(credential => {
                return createUserHandle(form.handle, credential.user.uid, credential.user.email)
                    .then(() => {
                        setUser({
                            user: credential.user
                        });
                    });
            })
            .then(() => {
                navigate('/');
            })
            // todo catch errors and display
    }

    return (
        <div className="signup-wrapper">
          <div className="form">
            <div className="flex-container">
              <div className="flex-item">
                <label htmlFor="firstName">First name</label>
                <input type="text" name="firstName" id="firstName" value={form.firstName} onChange={updateForm('firstName')} />
              </div>
              <div className="flex-item">
                <label htmlFor="lastName">Last name</label>
                <input type="text" name="lastName" id="lastName" value={form.lastName} onChange={updateForm('lastName')} />
              </div>
              <div className="flex-item">
                <label htmlFor="email">Email</label>
                <input type="email" name="email" id="email" value={form.email} onChange={updateForm('email')} />
              </div>
            </div>
            <div className="flex-container">
              <div className="flex-item">
                <label htmlFor="handle">Username</label>
                <input type="text" name="handle" id="handle" value={form.handle} onChange={updateForm('handle')} />
              </div>
              <div className="flex-item">
                <label htmlFor="password">Password</label>
                <input type="password" name="password" id="password" value={form.password} onChange={updateForm('password')} />
              </div>
            </div>
            <button onClick={onRegister}>Register</button>
          </div>
        </div>
      );
}