export default {
    plugins: [require('tailwindcss'), require('autoprefixer')],
  };
  